#include "kraken_msg.h"

void send_free(msg* m);


