#define SLAVE_UID 1011
#define SSH_CONFIG_PATH "/home/ucsd/kraken/reflex/coq/bench-ssh/test/ssh/kmsg-ssh/sshd_config"
#define SSH_HOST_RSA_KEY "/home/ucsd/kraken/reflex/coq/bench-ssh/test/ssh/kmsg-ssh/ssh_host_rsa_key"
#define SSH_SLV_PATH "/home/ucsd/kraken/reflex/coq/bench-ssh/test/ssh/kmsg-ssh/sshd"
#define SSH_SYS_PATH "/home/ucsd/kraken/reflex/coq/bench-ssh/test/ssh/kmsg-ssh/sshd_sys"
#define PTYER_SLV_PATH "/home/ucsd/kraken/reflex/coq/bench-ssh/test/ssh/kmsg-ssh/ptyer"
#define TMP_KEY_FILE "/home/ucsd/kraken/reflex/coq/bench-ssh/test/ssh/kmsg-ssh/tmp_keyfile"
